﻿namespace MVCSportStore.ViewModels
{
    public static class PaginaSettings
    {
        public static int ProductPagination = 4;
        public static bool PagingSettingsPage = false;
    }
}
